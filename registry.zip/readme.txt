The 6 registry*.uew files are for syntax highlighting *.reg files containing
Windows registry data.


registry1_1.uew
---------------

This wordfile supports code folding. With code folding it is possible to
fold from one [key] to next [key]. The last [key] in the registry file
can't be folded. This wordfile respectively the code folding feature
should not be used when working very often with registry files with
several MB containing thousands of [keys] as it may slow down viewing
and editing such larger registry files.

This wordfile highlights hexadecimal bytes, the commas between the bytes
and the backslashes at end of lines with hexadecimal bytes in the color
assigned to color group "Numbers" and "Hex. Bytes".

It is recommended to assign the same color to color group "Numbers" and
"Hex. Bytes" to get identical syntax highlighting for hexadecimal values
starting with [0-9a-f].


registry1_2.uew
---------------

This wordfile is like registry1_1.uew with the difference of specifying
also the comma as delimiter character. Therefore just the hexadecimal
bytes are highlighted with the assigned color of color groups "Numbers"
and "Hex. Bytes", but not the commas and the backslashes at end of lines.

It is recommended to assign the same color to color group "Numbers" and
"Hex. Bytes" to get identical syntax highlighting for hexadecimal values
starting with [0-9a-f].


registry1_3.uew
---------------

This wordfile is like registry1_2.uew with the difference of no color group
"Hex. Bytes". The color of color group "Numbers" should be set to the color
of normal text when using this wordfile to get all the hexadecimal bytes
highlighted as normal text. This speeds up the syntax highlighting a little
bit as the hexadecimal bytes are the only strings not special highlighted.
The commas and backslashes are highlighted instead.


registry2_1.uew
---------------

This wordfile does not support code folding. It interprets lines starting
with [ as comment line. Customize the color group "Comments" to adjust the
color for [keys]. In comparison to registry1_1.uew the syntax highlighting
with this wordfile is slightly faster which makes it better for syntax
highlighting *.reg files with several MB.

This wordfile highlights hexadecimal bytes, the commas between the bytes
and the backslashes at end of lines with hexadecimal bytes in the color
assigned to color group "Numbers" and "Hex. Bytes".

It is recommended to assign the same color to color group "Numbers" and
"Hex. Bytes" to get identical syntax highlighting for hexadecimal values
starting with [0-9a-f].


registry2_2.uew
---------------

This wordfile is like registry2_1.uew with the difference of specifying
also the comma as delimiter character. Therefore just the hexadecimal
bytes are highlighted with the assigned color of color groups "Numbers"
and "Hex. Bytes", but not the commas and the backslashes at end of lines.

It is recommended to assign the same color to color group "Numbers" and
"Hex. Bytes" to get identical syntax highlighting for hexadecimal values
starting with [0-9a-f].


registry2_3.uew
---------------

This wordfile is like registry2_2.uew with the difference of no color group
"Hex. Bytes". The color of color group "Numbers" should be set to the color
of normal text when using this wordfile to get all the hexadecimal bytes
highlighted as normal text. This speeds up the syntax highlighting a little
bit as the hexadecimal bytes are the only strings not special highlighted.
The commas and backslashes are highlighted instead.
