========================================================================================

                         SYNTAX HIGHLIGHTING IN ULTRAEDIT

========================================================================================

         Author: Christian Fuchs, StreamServe Germany GmbH
         Special Thanks to: Torsten Janssen, Vyv Lomax (StreamServe Stockholm)

========================================================================================

         Version: v 2.0
         Date:    13.11.2003
         
========================================================================================

         To configure StreamServe Highlighting, start UltraEdit, go to menu:
         Advanced > Configuration > Syntax Highlighting
         Here you can specify the Highlighting WORDFILE and associated Colour Settings of:

          - Strs_Script_X.X

         Colour Settings for StreamServe:

          - Strs_Conditions -> blue
          - Strs_Functions -> pink
          - String -> grey)

         Standard StreamServe Highlighting will now be used for Dux, Dua, and Fcn files
         as found in Strs_Script_X.X. 
	 At any time you may also manually select StreamServe Highlighting for any file by:
         Go to menu: View -> View As SyntaxHighlighting and select appropriate option.

         Further information(important):
         
         Read: WORDFILE_StreamServe_X.X_Scripting_only_Readme_ENG.TXT

========================================================================================

         Files included:
         WORDFILE_StreamServe_2.3_Scripting_only_v2.0.TXT
         WORDFILE_StreamServe_3.0_Scripting_only_v2.0.TXT
         WORDFILE_StreamServe_4.0_Scripting_only_v2.0.TXT
         WORDFILE_StreamServe_X.X_Scripting_only_Readme_ENG.TXT

========================================================================================
         
         Note:
         The Highlighting in these single files do not work in one WORDFILE.txt!!!
         All of them are default connected to DUX, DUA and FCN.
         Via argument: File Extensions = fcn dux dua

========================================================================================